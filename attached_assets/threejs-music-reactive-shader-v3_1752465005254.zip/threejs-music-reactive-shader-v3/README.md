# [threejs] ❍ Music Reactive Shader V3

A Pen created on CodePen.

Original URL: [https://codepen.io/filipz/pen/dPygJGM](https://codepen.io/filipz/pen/dPygJGM).

